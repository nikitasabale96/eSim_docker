EESchema Schematic File Version 2
LIBS:power
LIBS:device
LIBS:transistors
LIBS:conn
LIBS:linear
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:valves
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Plot
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_User
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L R R3
U 1 1 575BD042
P 5000 4200
F 0 "R3" V 5080 4200 50  0000 C CNN
F 1 "50k" V 5000 4200 50  0000 C CNN
F 2 "" V 4930 4200 50  0000 C CNN
F 3 "" H 5000 4200 50  0000 C CNN
	1    5000 4200
	1    0    0    -1  
$EndComp
$Comp
L R R4
U 1 1 575BD077
P 5050 3350
F 0 "R4" V 5130 3350 50  0000 C CNN
F 1 "200k" V 5050 3350 50  0000 C CNN
F 2 "" V 4980 3350 50  0000 C CNN
F 3 "" H 5050 3350 50  0000 C CNN
	1    5050 3350
	1    0    0    -1  
$EndComp
$Comp
L R R6
U 1 1 575BD0B0
P 5600 4450
F 0 "R6" V 5680 4450 50  0000 C CNN
F 1 "1.5k" V 5600 4450 50  0000 C CNN
F 2 "" V 5530 4450 50  0000 C CNN
F 3 "" H 5600 4450 50  0000 C CNN
	1    5600 4450
	1    0    0    -1  
$EndComp
$Comp
L R R5
U 1 1 575BD0FD
P 5600 3200
F 0 "R5" V 5680 3200 50  0000 C CNN
F 1 "2.5k" V 5600 3200 50  0000 C CNN
F 2 "" V 5530 3200 50  0000 C CNN
F 3 "" H 5600 3200 50  0000 C CNN
	1    5600 3200
	1    0    0    -1  
$EndComp
Wire Wire Line
	5600 3350 5600 3650
Wire Wire Line
	5600 4050 5600 4300
Wire Wire Line
	5000 4600 6600 4600
Wire Wire Line
	5000 4350 5000 5050
Wire Wire Line
	5050 3500 5050 4050
Wire Wire Line
	5050 4050 5000 4050
Connection ~ 5050 3850
Wire Wire Line
	5050 3200 5050 3050
Wire Wire Line
	5050 3050 5600 3050
$Comp
L C C1
U 1 1 575BD2DC
P 4600 3850
F 0 "C1" H 4625 3950 50  0000 L CNN
F 1 "22u" H 4625 3750 50  0000 L CNN
F 2 "" H 4638 3700 50  0000 C CNN
F 3 "" H 4600 3850 50  0000 C CNN
	1    4600 3850
	0    1    1    0   
$EndComp
$Comp
L GND #PWR01
U 1 1 575BD445
P 5300 4600
F 0 "#PWR01" H 5300 4350 50  0001 C CNN
F 1 "GND" H 5300 4450 50  0000 C CNN
F 2 "" H 5300 4600 50  0000 C CNN
F 3 "" H 5300 4600 50  0000 C CNN
	1    5300 4600
	1    0    0    -1  
$EndComp
$Comp
L DC v2
U 1 1 575BD554
P 6150 2450
F 0 "v2" H 5950 2550 60  0000 C CNN
F 1 "DC" H 5950 2400 60  0000 C CNN
F 2 "R1" H 5850 2450 60  0000 C CNN
F 3 "" H 6150 2450 60  0000 C CNN
	1    6150 2450
	1    0    0    -1  
$EndComp
Wire Wire Line
	6150 2000 5350 2000
Wire Wire Line
	5350 2000 5350 3050
Connection ~ 5350 3050
Wire Wire Line
	5000 5050 3650 5050
Connection ~ 5000 4600
$Comp
L GND #PWR02
U 1 1 575BD78B
P 6200 3000
F 0 "#PWR02" H 6200 2750 50  0001 C CNN
F 1 "GND" H 6200 2850 50  0000 C CNN
F 2 "" H 6200 3000 50  0000 C CNN
F 3 "" H 6200 3000 50  0000 C CNN
	1    6200 3000
	1    0    0    -1  
$EndComp
Wire Wire Line
	6150 2900 6150 3000
Wire Wire Line
	6150 3000 6200 3000
$Comp
L C C3
U 1 1 575BDCC4
P 6400 3750
F 0 "C3" H 6425 3850 50  0000 L CNN
F 1 "22u" H 6425 3650 50  0000 L CNN
F 2 "" H 6438 3600 50  0000 C CNN
F 3 "" H 6400 3750 50  0000 C CNN
	1    6400 3750
	0    1    1    0   
$EndComp
Wire Wire Line
	5600 3650 6250 3650
Wire Wire Line
	6250 3650 6250 3750
$Comp
L NPN Q1
U 1 1 575BDDAF
P 5500 3850
F 0 "Q1" H 5400 3900 50  0000 R CNN
F 1 "NPN" H 5450 4000 50  0000 R CNN
F 2 "" H 5700 3950 29  0000 C CNN
F 3 "" H 5500 3850 60  0000 C CNN
	1    5500 3850
	1    0    0    -1  
$EndComp
$Comp
L R R7
U 1 1 575BDFE6
P 6600 4150
F 0 "R7" V 6680 4150 50  0000 C CNN
F 1 "1k" V 6600 4150 50  0000 C CNN
F 2 "" V 6530 4150 50  0000 C CNN
F 3 "" H 6600 4150 50  0000 C CNN
	1    6600 4150
	1    0    0    -1  
$EndComp
$Comp
L C C2
U 1 1 575BE02B
P 5850 4400
F 0 "C2" H 5875 4500 50  0000 L CNN
F 1 "37u" H 5875 4300 50  0000 L CNN
F 2 "" H 5888 4250 50  0000 C CNN
F 3 "" H 5850 4400 50  0000 C CNN
	1    5850 4400
	1    0    0    -1  
$EndComp
Wire Wire Line
	6550 3700 6550 4000
Wire Wire Line
	6550 4000 6600 4000
Wire Wire Line
	6600 4600 6600 4300
Connection ~ 5600 4600
Wire Wire Line
	5850 4550 5850 4600
Connection ~ 5850 4600
Wire Wire Line
	5850 4250 5600 4250
Connection ~ 5600 4250
$Comp
L sine v1
U 1 1 575BD4D7
P 3650 4600
F 0 "v1" H 3450 4700 60  0000 C CNN
F 1 "sine" H 3450 4550 60  0000 C CNN
F 2 "R1" H 3350 4600 60  0000 C CNN
F 3 "" H 3650 4600 60  0000 C CNN
	1    3650 4600
	1    0    0    -1  
$EndComp
$Comp
L R R2
U 1 1 575BE2C7
P 3850 3850
F 0 "R2" H 3930 3850 50  0000 C CNN
F 1 "50" V 3850 3850 50  0000 C CNN
F 2 "" V 3780 3850 50  0000 C CNN
F 3 "" H 3850 3850 50  0000 C CNN
	1    3850 3850
	0    1    1    0   
$EndComp
Wire Wire Line
	4750 3850 5300 3850
Wire Wire Line
	4000 3850 4450 3850
Wire Wire Line
	3700 3850 3650 3850
Wire Wire Line
	3650 3600 3650 4150
Connection ~ 4000 3850
Text GLabel 3650 3600 0    60   Input ~ 0
IN
Connection ~ 3650 3850
Text GLabel 6850 3700 2    60   Input ~ 0
OUT
Wire Wire Line
	6850 3700 6550 3700
Connection ~ 6550 3750
$Comp
L plot_v1 U1
U 1 1 575BEB88
P 3650 3650
F 0 "U1" H 3650 4150 60  0000 C CNN
F 1 "plot_v1" H 3850 4000 60  0000 C CNN
F 2 "" H 3650 3650 60  0000 C CNN
F 3 "" H 3650 3650 60  0000 C CNN
	1    3650 3650
	1    0    0    -1  
$EndComp
Wire Wire Line
	3650 3450 3650 3700
Connection ~ 3650 3700
$Comp
L plot_v1 U2
U 1 1 575BECB8
P 6550 3900
F 0 "U2" H 6550 4400 60  0000 C CNN
F 1 "plot_v1" H 6750 4250 60  0000 C CNN
F 2 "" H 6550 3900 60  0000 C CNN
F 3 "" H 6550 3900 60  0000 C CNN
	1    6550 3900
	1    0    0    -1  
$EndComp
$EndSCHEMATC
