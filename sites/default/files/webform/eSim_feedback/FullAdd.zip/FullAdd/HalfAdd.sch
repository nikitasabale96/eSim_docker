EESchema Schematic File Version 2
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:power
LIBS:device
LIBS:transistors
LIBS:conn
LIBS:linear
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_User
LIBS:eSim_Plot
LIBS:eSim_PSpice
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L d_xor U2
U 1 1 575BECED
P 5150 2400
F 0 "U2" H 5150 2400 60  0000 C CNN
F 1 "d_xor" H 5200 2500 47  0000 C CNN
F 2 "" H 5150 2400 60  0000 C CNN
F 3 "" H 5150 2400 60  0000 C CNN
	1    5150 2400
	1    0    0    -1  
$EndComp
$Comp
L d_and U3
U 1 1 575BED4A
P 5200 2850
F 0 "U3" H 5200 2850 60  0000 C CNN
F 1 "d_and" H 5250 2950 60  0000 C CNN
F 2 "" H 5200 2850 60  0000 C CNN
F 3 "" H 5200 2850 60  0000 C CNN
	1    5200 2850
	1    0    0    -1  
$EndComp
$Comp
L PORT U1
U 1 1 575BEDD1
P 4150 2200
F 0 "U1" H 4200 2300 30  0000 C CNN
F 1 "PORT" H 4150 2200 30  0000 C CNN
F 2 "" H 4150 2200 60  0000 C CNN
F 3 "" H 4150 2200 60  0000 C CNN
	1    4150 2200
	1    0    0    -1  
$EndComp
$Comp
L PORT U1
U 2 1 575BEEE8
P 4150 2500
F 0 "U1" H 4200 2600 30  0000 C CNN
F 1 "PORT" H 4150 2500 30  0000 C CNN
F 2 "" H 4150 2500 60  0000 C CNN
F 3 "" H 4150 2500 60  0000 C CNN
	2    4150 2500
	1    0    0    -1  
$EndComp
Wire Wire Line
	4400 2200 4450 2200
Wire Wire Line
	4450 2200 4450 2300
Wire Wire Line
	4450 2300 4700 2300
Wire Wire Line
	4400 2500 4450 2500
Wire Wire Line
	4450 2500 4450 2400
Wire Wire Line
	4450 2400 4700 2400
Wire Wire Line
	4750 2750 4650 2750
Wire Wire Line
	4650 2750 4650 2300
Connection ~ 4650 2300
Wire Wire Line
	4550 2400 4550 2850
Wire Wire Line
	4550 2850 4750 2850
Connection ~ 4550 2400
$Comp
L PORT U1
U 3 1 575BF074
P 5900 2350
F 0 "U1" H 5950 2450 30  0000 C CNN
F 1 "PORT" H 5900 2350 30  0000 C CNN
F 2 "" H 5900 2350 60  0000 C CNN
F 3 "" H 5900 2350 60  0000 C CNN
	3    5900 2350
	-1   0    0    1   
$EndComp
$Comp
L PORT U1
U 4 1 575BF0FF
P 5950 2800
F 0 "U1" H 6000 2900 30  0000 C CNN
F 1 "PORT" H 5950 2800 30  0000 C CNN
F 2 "" H 5950 2800 60  0000 C CNN
F 3 "" H 5950 2800 60  0000 C CNN
	4    5950 2800
	-1   0    0    1   
$EndComp
Wire Wire Line
	5600 2350 5650 2350
Wire Wire Line
	5650 2800 5700 2800
$EndSCHEMATC
