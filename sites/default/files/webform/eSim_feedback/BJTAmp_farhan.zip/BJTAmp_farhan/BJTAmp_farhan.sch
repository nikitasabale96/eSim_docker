EESchema Schematic File Version 2
LIBS:power
LIBS:device
LIBS:transistors
LIBS:conn
LIBS:linear
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:valves
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Plot
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_User
LIBS:BJTAmp_farhan-cache
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L NPN Q1
U 1 1 575BD085
P 5400 3750
F 0 "Q1" H 5300 3800 50  0000 R CNN
F 1 "NPN" H 5350 3900 50  0000 R CNN
F 2 "" H 5600 3850 29  0000 C CNN
F 3 "" H 5400 3750 60  0000 C CNN
	1    5400 3750
	1    0    0    -1  
$EndComp
$Comp
L R R3
U 1 1 575BD0E5
P 5500 2900
F 0 "R3" V 5580 2900 50  0000 C CNN
F 1 "2k" V 5500 2900 50  0000 C CNN
F 2 "" V 5430 2900 50  0000 C CNN
F 3 "" H 5500 2900 50  0000 C CNN
	1    5500 2900
	1    0    0    -1  
$EndComp
$Comp
L R R2
U 1 1 575BD1CC
P 4950 4400
F 0 "R2" V 5030 4400 50  0000 C CNN
F 1 "50k" V 4950 4400 50  0000 C CNN
F 2 "" V 4880 4400 50  0000 C CNN
F 3 "" H 4950 4400 50  0000 C CNN
	1    4950 4400
	1    0    0    -1  
$EndComp
$Comp
L R R1
U 1 1 575BD1FF
P 4950 2900
F 0 "R1" V 5030 2900 50  0000 C CNN
F 1 "200k" V 4950 2900 50  0000 C CNN
F 2 "" V 4880 2900 50  0000 C CNN
F 3 "" H 4950 2900 50  0000 C CNN
	1    4950 2900
	1    0    0    -1  
$EndComp
$Comp
L R R4
U 1 1 575BD24E
P 5500 4400
F 0 "R4" V 5580 4400 50  0000 C CNN
F 1 "1.5k" V 5500 4400 50  0000 C CNN
F 2 "" V 5430 4400 50  0000 C CNN
F 3 "" H 5500 4400 50  0000 C CNN
	1    5500 4400
	1    0    0    -1  
$EndComp
$Comp
L C C2
U 1 1 575BD438
P 6100 4250
F 0 "C2" H 6125 4350 50  0000 L CNN
F 1 "100u" H 6125 4150 50  0000 L CNN
F 2 "" H 6138 4100 50  0000 C CNN
F 3 "" H 6100 4250 50  0000 C CNN
	1    6100 4250
	1    0    0    -1  
$EndComp
$Comp
L C C3
U 1 1 575BD48D
P 6250 3450
F 0 "C3" H 6275 3550 50  0000 L CNN
F 1 "40u" H 6275 3350 50  0000 L CNN
F 2 "" H 6288 3300 50  0000 C CNN
F 3 "" H 6250 3450 50  0000 C CNN
	1    6250 3450
	0    -1   -1   0   
$EndComp
$Comp
L C C1
U 1 1 575BD517
P 4450 3750
F 0 "C1" H 4475 3850 50  0000 L CNN
F 1 "40u" H 4475 3650 50  0000 L CNN
F 2 "" H 4488 3600 50  0000 C CNN
F 3 "" H 4450 3750 50  0000 C CNN
	1    4450 3750
	0    1    1    0   
$EndComp
$Comp
L GND #PWR01
U 1 1 575BDE2C
P 5350 4700
F 0 "#PWR01" H 5350 4450 50  0001 C CNN
F 1 "GND" H 5350 4550 50  0000 C CNN
F 2 "" H 5350 4700 50  0000 C CNN
F 3 "" H 5350 4700 50  0000 C CNN
	1    5350 4700
	1    0    0    -1  
$EndComp
$Comp
L sine V2
U 1 1 575BE07B
P 3850 4200
F 0 "V2" H 3650 4300 60  0000 C CNN
F 1 "sine" H 3650 4150 60  0000 C CNN
F 2 "R1" H 3550 4200 60  0000 C CNN
F 3 "" H 3850 4200 60  0000 C CNN
	1    3850 4200
	1    0    0    -1  
$EndComp
$Comp
L DC V1
U 1 1 575BE2CC
P 7050 3900
F 0 "V1" H 6850 4000 60  0000 C CNN
F 1 "DC" H 6850 3850 60  0000 C CNN
F 2 "R1" H 6750 3900 60  0000 C CNN
F 3 "" H 7050 3900 60  0000 C CNN
	1    7050 3900
	1    0    0    -1  
$EndComp
Wire Wire Line
	5500 3600 5500 3050
Wire Wire Line
	5500 3950 5500 4250
Wire Wire Line
	5250 3750 4600 3750
Wire Wire Line
	4950 3050 4950 4250
Connection ~ 4950 3750
Wire Wire Line
	4950 2750 7050 2750
Wire Wire Line
	6100 4550 4950 4550
Wire Wire Line
	5500 4100 6100 4100
Connection ~ 5500 4100
Wire Wire Line
	6100 4350 6100 4550
Connection ~ 6100 4400
Connection ~ 5500 4550
Wire Wire Line
	6100 3450 5500 3450
Wire Wire Line
	5500 3450 5500 3400
Connection ~ 5500 3400
Wire Wire Line
	5350 4550 5350 4750
Connection ~ 5350 4550
Wire Wire Line
	3850 4650 7050 4650
Connection ~ 5350 4650
Wire Wire Line
	7050 2750 7050 3450
Connection ~ 5500 2750
Wire Wire Line
	6400 3450 6600 3450
Wire Wire Line
	7050 4650 7050 4350
$Comp
L R R6
U 1 1 575BEDE3
P 6450 4000
F 0 "R6" V 6530 4000 50  0000 C CNN
F 1 "1k" V 6450 4000 50  0000 C CNN
F 2 "" V 6380 4000 50  0000 C CNN
F 3 "" H 6450 4000 50  0000 C CNN
	1    6450 4000
	1    0    0    -1  
$EndComp
Wire Wire Line
	6400 3450 6400 3850
Wire Wire Line
	6400 3850 6450 3850
Wire Wire Line
	6450 4150 6450 4650
Connection ~ 6450 4650
Connection ~ 6100 3450
$Comp
L R R0
U 1 1 575BEF66
P 4000 3750
F 0 "R0" V 4080 3750 50  0000 C CNN
F 1 "50" V 4000 3750 50  0000 C CNN
F 2 "" V 3930 3750 50  0000 C CNN
F 3 "" H 4000 3750 50  0000 C CNN
	1    4000 3750
	0    1    1    0   
$EndComp
Wire Wire Line
	4300 3750 4150 3750
Connection ~ 3850 3750
Connection ~ 6400 3450
Text GLabel 3650 3550 0    60   Input ~ 0
IN
Wire Wire Line
	3650 3550 3850 3550
Wire Wire Line
	3850 3250 3850 3750
Text GLabel 6600 3450 2    60   Input ~ 0
OUT
$Comp
L plot_v1 U1
U 1 1 575BFA1B
P 3850 3450
F 0 "U1" H 3850 3950 60  0000 C CNN
F 1 "plot_v1" H 4050 3800 60  0000 C CNN
F 2 "" H 3850 3450 60  0000 C CNN
F 3 "" H 3850 3450 60  0000 C CNN
	1    3850 3450
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U2
U 1 1 575BFA82
P 6500 3400
F 0 "U2" H 6500 3900 60  0000 C CNN
F 1 "plot_v1" H 6700 3750 60  0000 C CNN
F 2 "" H 6500 3400 60  0000 C CNN
F 3 "" H 6500 3400 60  0000 C CNN
	1    6500 3400
	1    0    0    -1  
$EndComp
Connection ~ 3850 3550
Wire Wire Line
	6500 3200 6500 3450
Connection ~ 6500 3450
Connection ~ 5500 3600
Connection ~ 5250 3750
Connection ~ 5500 3950
Connection ~ 3650 3550
Connection ~ 6600 3450
Connection ~ 5500 3550
Connection ~ 5200 3750
Connection ~ 5350 4700
Connection ~ 5350 4750
$EndSCHEMATC
