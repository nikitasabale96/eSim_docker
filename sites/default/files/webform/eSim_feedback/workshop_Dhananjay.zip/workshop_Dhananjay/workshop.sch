EESchema Schematic File Version 2
LIBS:power
LIBS:device
LIBS:transistors
LIBS:conn
LIBS:linear
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:valves
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Plot
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_User
LIBS:workshop-cache
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L NPN Q1
U 1 1 575BD08D
P 3350 3200
F 0 "Q1" H 3250 3250 50  0000 R CNN
F 1 "NPN" H 3300 3350 50  0000 R CNN
F 2 "" H 3550 3300 29  0000 C CNN
F 3 "" H 3350 3200 60  0000 C CNN
	1    3350 3200
	1    0    0    -1  
$EndComp
$Comp
L R R3
U 1 1 575BD135
P 3450 2850
F 0 "R3" V 3530 2850 50  0000 C CNN
F 1 "2.2k" V 3450 2850 50  0000 C CNN
F 2 "" V 3380 2850 50  0000 C CNN
F 3 "" H 3450 2850 50  0000 C CNN
	1    3450 2850
	1    0    0    -1  
$EndComp
$Comp
L R R1
U 1 1 575BD1B4
P 2850 2900
F 0 "R1" V 2930 2900 50  0000 C CNN
F 1 "33k" V 2850 2900 50  0000 C CNN
F 2 "" V 2780 2900 50  0000 C CNN
F 3 "" H 2850 2900 50  0000 C CNN
	1    2850 2900
	1    0    0    -1  
$EndComp
$Comp
L R R4
U 1 1 575BD1F1
P 3450 3550
F 0 "R4" V 3530 3550 50  0000 C CNN
F 1 "1k" V 3450 3550 50  0000 C CNN
F 2 "" V 3380 3550 50  0000 C CNN
F 3 "" H 3450 3550 50  0000 C CNN
	1    3450 3550
	1    0    0    -1  
$EndComp
$Comp
L R R2
U 1 1 575BD28C
P 2850 3550
F 0 "R2" V 2930 3550 50  0000 C CNN
F 1 "6.8k" V 2850 3550 50  0000 C CNN
F 2 "" V 2780 3550 50  0000 C CNN
F 3 "" H 2850 3550 50  0000 C CNN
	1    2850 3550
	1    0    0    -1  
$EndComp
$Comp
L C C1
U 1 1 575BD307
P 2450 3200
F 0 "C1" H 2475 3300 50  0000 L CNN
F 1 "10u" H 2475 3100 50  0000 L CNN
F 2 "" H 2488 3050 50  0000 C CNN
F 3 "" H 2450 3200 50  0000 C CNN
	1    2450 3200
	0    1    1    0   
$EndComp
$Comp
L C C3
U 1 1 575BD376
P 3900 3000
F 0 "C3" H 3925 3100 50  0000 L CNN
F 1 "10u" H 3925 2900 50  0000 L CNN
F 2 "" H 3938 2850 50  0000 C CNN
F 3 "" H 3900 3000 50  0000 C CNN
	1    3900 3000
	0    1    1    0   
$EndComp
$Comp
L GND #PWR01
U 1 1 575BD399
P 3200 4050
F 0 "#PWR01" H 3200 3800 50  0001 C CNN
F 1 "GND" H 3200 3900 50  0000 C CNN
F 2 "" H 3200 4050 50  0000 C CNN
F 3 "" H 3200 4050 50  0000 C CNN
	1    3200 4050
	1    0    0    -1  
$EndComp
$Comp
L DC v2
U 1 1 575BD3BB
P 4600 3250
F 0 "v2" H 4400 3350 60  0000 C CNN
F 1 "DC" H 4400 3200 60  0000 C CNN
F 2 "R1" H 4300 3250 60  0000 C CNN
F 3 "" H 4600 3250 60  0000 C CNN
	1    4600 3250
	1    0    0    -1  
$EndComp
$Comp
L sine v1
U 1 1 575BD3E0
P 1800 3650
F 0 "v1" H 1600 3750 60  0000 C CNN
F 1 "sine" H 1600 3600 60  0000 C CNN
F 2 "R1" H 1500 3650 60  0000 C CNN
F 3 "" H 1800 3650 60  0000 C CNN
	1    1800 3650
	1    0    0    -1  
$EndComp
Wire Wire Line
	2600 3200 3150 3200
Wire Wire Line
	2850 3700 3850 3700
Connection ~ 2850 3200
Wire Wire Line
	2850 2750 2850 2650
Wire Wire Line
	2850 2650 4600 2650
Wire Wire Line
	3450 2650 3450 2700
Wire Wire Line
	3750 3000 3450 3000
$Comp
L C C2
U 1 1 575BEC37
P 3850 3550
F 0 "C2" H 3875 3650 50  0000 L CNN
F 1 "100u" H 3875 3450 50  0000 L CNN
F 2 "" H 3888 3400 50  0000 C CNN
F 3 "" H 3850 3550 50  0000 C CNN
	1    3850 3550
	1    0    0    -1  
$EndComp
Connection ~ 3450 3700
Connection ~ 3200 3700
Wire Wire Line
	3850 3400 3450 3400
Wire Wire Line
	4600 2650 4600 2800
Connection ~ 3450 2650
Wire Wire Line
	4600 3900 4600 3700
Wire Wire Line
	2900 3900 4600 3900
Connection ~ 3200 3900
Wire Wire Line
	1800 4100 2900 4100
Wire Wire Line
	2900 4100 2900 3900
Text GLabel 1700 3000 0    60   Input ~ 0
Input
Text GLabel 4200 3000 2    60   Input ~ 0
out
Wire Wire Line
	1700 3000 1850 3000
Wire Wire Line
	1850 3000 1850 3200
Connection ~ 1850 3200
$Comp
L plot_v1 U1
U 1 1 575C08AE
P 1850 3200
F 0 "U1" H 1850 3700 60  0000 C CNN
F 1 "plot_v1" H 2050 3550 60  0000 C CNN
F 2 "" H 1850 3200 60  0000 C CNN
F 3 "" H 1850 3200 60  0000 C CNN
	1    1850 3200
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U2
U 1 1 575C097E
P 4100 3200
F 0 "U2" H 4100 3700 60  0000 C CNN
F 1 "plot_v1" H 4300 3550 60  0000 C CNN
F 2 "" H 4100 3200 60  0000 C CNN
F 3 "" H 4100 3200 60  0000 C CNN
	1    4100 3200
	1    0    0    -1  
$EndComp
Wire Wire Line
	4050 3000 4200 3000
Connection ~ 4100 3000
Wire Wire Line
	2850 3050 2850 3400
Wire Wire Line
	1800 3200 2300 3200
Wire Wire Line
	3200 3700 3200 4050
Connection ~ 3200 4050
$Comp
L R R5
U 1 1 575BE4B8
P 4100 3550
F 0 "R5" V 4180 3550 50  0000 C CNN
F 1 "1k" V 4100 3550 50  0000 C CNN
F 2 "" V 4030 3550 50  0000 C CNN
F 3 "" H 4100 3550 50  0000 C CNN
	1    4100 3550
	1    0    0    -1  
$EndComp
Wire Wire Line
	4100 3400 4100 3000
Wire Wire Line
	4100 3700 4100 3900
Connection ~ 4100 3900
$EndSCHEMATC
