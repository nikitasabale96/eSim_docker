EESchema Schematic File Version 2
LIBS:power
LIBS:device
LIBS:transistors
LIBS:conn
LIBS:linear
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:valves
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Plot
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_User
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L NPN Q1
U 1 1 575BD004
P 4550 3450
F 0 "Q1" H 4450 3500 50  0000 R CNN
F 1 "NPN" H 4500 3600 50  0000 R CNN
F 2 "" H 4750 3550 29  0000 C CNN
F 3 "" H 4550 3450 60  0000 C CNN
	1    4550 3450
	1    0    0    -1  
$EndComp
$Comp
L R R5
U 1 1 575BD06F
P 4650 4100
F 0 "R5" V 4730 4100 50  0000 C CNN
F 1 "1.5k" V 4650 4100 50  0000 C CNN
F 2 "" V 4580 4100 50  0000 C CNN
F 3 "" H 4650 4100 50  0000 C CNN
	1    4650 4100
	1    0    0    -1  
$EndComp
$Comp
L C C1
U 1 1 575BD0EE
P 3400 3450
F 0 "C1" H 3425 3550 50  0000 L CNN
F 1 "40u" H 3425 3350 50  0000 L CNN
F 2 "" H 3438 3300 50  0000 C CNN
F 3 "" H 3400 3450 50  0000 C CNN
	1    3400 3450
	0    1    1    0   
$EndComp
$Comp
L C C2
U 1 1 575BD507
P 5150 3200
F 0 "C2" H 5175 3300 50  0000 L CNN
F 1 "40u" H 5175 3100 50  0000 L CNN
F 2 "" H 5188 3050 50  0000 C CNN
F 3 "" H 5150 3200 50  0000 C CNN
	1    5150 3200
	0    1    1    0   
$EndComp
$Comp
L GND #PWR01
U 1 1 575BD591
P 4600 4550
F 0 "#PWR01" H 4600 4300 50  0001 C CNN
F 1 "GND" H 4600 4400 50  0000 C CNN
F 2 "" H 4600 4550 50  0000 C CNN
F 3 "" H 4600 4550 50  0000 C CNN
	1    4600 4550
	1    0    0    -1  
$EndComp
$Comp
L R R4
U 1 1 575BD5AF
P 4650 3000
F 0 "R4" V 4730 3000 50  0000 C CNN
F 1 "2k" V 4650 3000 50  0000 C CNN
F 2 "" V 4580 3000 50  0000 C CNN
F 3 "" H 4650 3000 50  0000 C CNN
	1    4650 3000
	1    0    0    -1  
$EndComp
$Comp
L sine v1
U 1 1 575BD790
P 2350 3900
F 0 "v1" H 2150 4000 60  0000 C CNN
F 1 "sine" H 2150 3850 60  0000 C CNN
F 2 "R1" H 2050 3900 60  0000 C CNN
F 3 "" H 2350 3900 60  0000 C CNN
	1    2350 3900
	1    0    0    -1  
$EndComp
$Comp
L DC v2
U 1 1 575BD7ED
P 6350 3600
F 0 "v2" H 6150 3700 60  0000 C CNN
F 1 "DC" H 6150 3550 60  0000 C CNN
F 2 "R1" H 6050 3600 60  0000 C CNN
F 3 "" H 6350 3600 60  0000 C CNN
	1    6350 3600
	1    0    0    -1  
$EndComp
$Comp
L R R2
U 1 1 575BDDB6
P 3800 3100
F 0 "R2" V 3880 3100 50  0000 C CNN
F 1 "200k" V 3800 3100 50  0000 C CNN
F 2 "" V 3730 3100 50  0000 C CNN
F 3 "" H 3800 3100 50  0000 C CNN
	1    3800 3100
	1    0    0    -1  
$EndComp
$Comp
L R R3
U 1 1 575BDE20
P 3800 4000
F 0 "R3" V 3900 4000 50  0000 C CNN
F 1 "50k" V 3800 4000 50  0000 C CNN
F 2 "" V 3730 4000 50  0000 C CNN
F 3 "" H 3800 4000 50  0000 C CNN
	1    3800 4000
	1    0    0    -1  
$EndComp
$Comp
L R R1
U 1 1 575BE0D6
P 2900 3450
F 0 "R1" V 2980 3450 50  0000 C CNN
F 1 "50" V 2900 3450 50  0000 C CNN
F 2 "" V 2830 3450 50  0000 C CNN
F 3 "" H 2900 3450 50  0000 C CNN
	1    2900 3450
	0    1    1    0   
$EndComp
$Comp
L C C3
U 1 1 575BE1F4
P 5150 3950
F 0 "C3" H 5175 4050 50  0000 L CNN
F 1 "100u" H 5175 3850 50  0000 L CNN
F 2 "" H 5188 3800 50  0000 C CNN
F 3 "" H 5150 3950 50  0000 C CNN
	1    5150 3950
	-1   0    0    1   
$EndComp
$Comp
L R R6
U 1 1 575BE28F
P 5650 3500
F 0 "R6" V 5730 3500 50  0000 C CNN
F 1 "1k" V 5650 3500 50  0000 C CNN
F 2 "" V 5580 3500 50  0000 C CNN
F 3 "" H 5650 3500 50  0000 C CNN
	1    5650 3500
	1    0    0    -1  
$EndComp
Text GLabel 2100 3350 0    60   Input ~ 0
INPUT
Text GLabel 5700 3000 2    60   Input ~ 0
OUTPUT
$Comp
L plot_v1 U1
U 1 1 575C1A9E
P 2550 3250
F 0 "U1" H 2550 3750 60  0000 C CNN
F 1 "plot_v1" H 2750 3600 60  0000 C CNN
F 2 "" H 2550 3250 60  0000 C CNN
F 3 "" H 2550 3250 60  0000 C CNN
	1    2550 3250
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U2
U 1 1 575C2268
P 5650 2800
F 0 "U2" H 5650 3300 60  0000 C CNN
F 1 "plot_v1" H 5850 3150 60  0000 C CNN
F 2 "" H 5650 2800 60  0000 C CNN
F 3 "" H 5650 2800 60  0000 C CNN
	1    5650 2800
	1    0    0    -1  
$EndComp
Wire Wire Line
	3800 2950 3800 2850
Wire Wire Line
	3800 2850 6350 2850
Wire Wire Line
	4650 2850 4650 2900
Wire Wire Line
	4650 3150 4650 3250
Wire Wire Line
	4650 3650 4650 3950
Wire Wire Line
	2350 4400 4650 4400
Wire Wire Line
	4600 4400 6350 4400
Wire Wire Line
	3550 3450 4350 3450
Connection ~ 3800 3450
Wire Wire Line
	3050 3450 3250 3450
Wire Wire Line
	4650 3200 5000 3200
Connection ~ 4650 3200
Wire Wire Line
	4650 3750 5150 3750
Wire Wire Line
	4650 3750 4650 3800
Connection ~ 4650 3750
Connection ~ 4600 4400
Wire Wire Line
	5650 3200 5300 3200
Wire Wire Line
	5650 2600 5650 3350
Wire Wire Line
	5650 4400 5650 3650
Wire Wire Line
	6350 2850 6350 3150
Connection ~ 4650 2850
Connection ~ 5650 4400
Wire Wire Line
	5150 3750 5150 3800
Wire Wire Line
	5150 4400 5150 4100
Connection ~ 5150 4400
Wire Wire Line
	2350 4350 2350 4400
Wire Wire Line
	4650 4400 4650 4250
Wire Wire Line
	4600 4400 4600 4550
Connection ~ 3800 4400
Wire Wire Line
	6350 4400 6350 4050
Wire Wire Line
	2350 3450 2750 3450
Wire Wire Line
	5700 3000 5650 3000
Connection ~ 5650 3200
Wire Wire Line
	2550 3050 2550 3450
Connection ~ 2550 3450
Connection ~ 5650 3000
Wire Wire Line
	2100 3350 2550 3350
Connection ~ 2550 3350
Wire Wire Line
	3800 3250 3800 3850
Wire Wire Line
	3800 4400 3800 4150
$EndSCHEMATC
