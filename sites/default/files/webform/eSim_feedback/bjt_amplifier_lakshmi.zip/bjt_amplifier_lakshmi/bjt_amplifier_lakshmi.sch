EESchema Schematic File Version 2
LIBS:power
LIBS:device
LIBS:transistors
LIBS:conn
LIBS:linear
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:valves
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Plot
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_User
LIBS:bjt_amplifier_lakshmi-cache
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L NPN Q1
U 1 1 575BCFC4
P 5500 2900
F 0 "Q1" H 5400 2950 50  0000 R CNN
F 1 "NPN" H 5450 3050 50  0000 R CNN
F 2 "" H 5700 3000 29  0000 C CNN
F 3 "" H 5500 2900 60  0000 C CNN
	1    5500 2900
	1    0    0    -1  
$EndComp
$Comp
L R rc1
U 1 1 575BD0A5
P 5300 2650
F 0 "rc1" V 5380 2650 50  0000 C CNN
F 1 "2k" V 5300 2650 50  0000 C CNN
F 2 "" V 5230 2650 50  0000 C CNN
F 3 "" H 5300 2650 50  0000 C CNN
	1    5300 2650
	1    0    0    -1  
$EndComp
$Comp
L R re1
U 1 1 575BD112
P 5550 3250
F 0 "re1" V 5630 3250 50  0000 C CNN
F 1 "1.5k" V 5550 3250 50  0000 C CNN
F 2 "" V 5480 3250 50  0000 C CNN
F 3 "" H 5550 3250 50  0000 C CNN
	1    5550 3250
	1    0    0    -1  
$EndComp
$Comp
L R r2
U 1 1 575BD3F6
P 5050 3300
F 0 "r2" V 5130 3300 50  0000 C CNN
F 1 "50k" V 5050 3300 50  0000 C CNN
F 2 "" V 4980 3300 50  0000 C CNN
F 3 "" H 5050 3300 50  0000 C CNN
	1    5050 3300
	1    0    0    -1  
$EndComp
$Comp
L R r1
U 1 1 575BD4B0
P 5050 2650
F 0 "r1" V 5130 2650 50  0000 C CNN
F 1 "200k" V 5050 2650 50  0000 C CNN
F 2 "" V 4980 2650 50  0000 C CNN
F 3 "" H 5050 2650 50  0000 C CNN
	1    5050 2650
	1    0    0    -1  
$EndComp
$Comp
L C cc1
U 1 1 575BD5B8
P 4800 2900
F 0 "cc1" H 4825 3000 50  0000 L CNN
F 1 "40u" H 4825 2800 50  0000 L CNN
F 2 "" H 4838 2750 50  0000 C CNN
F 3 "" H 4800 2900 50  0000 C CNN
	1    4800 2900
	0    1    1    0   
$EndComp
$Comp
L C cc2
U 1 1 575BD7F7
P 6000 2750
F 0 "cc2" H 6025 2850 50  0000 L CNN
F 1 "40u" H 6025 2650 50  0000 L CNN
F 2 "" H 6038 2600 50  0000 C CNN
F 3 "" H 6000 2750 50  0000 C CNN
	1    6000 2750
	0    -1   -1   0   
$EndComp
$Comp
L R ro1
U 1 1 575BDBDD
P 6150 2900
F 0 "ro1" V 6230 2900 50  0000 C CNN
F 1 "1k" V 6150 2900 50  0000 C CNN
F 2 "" V 6080 2900 50  0000 C CNN
F 3 "" H 6150 2900 50  0000 C CNN
	1    6150 2900
	1    0    0    -1  
$EndComp
$Comp
L DC v1
U 1 1 575BDEE6
P 6950 2950
F 0 "v1" H 6750 3050 60  0000 C CNN
F 1 "DC" H 6750 2900 60  0000 C CNN
F 2 "R1" H 6650 2950 60  0000 C CNN
F 3 "" H 6950 2950 60  0000 C CNN
	1    6950 2950
	1    0    0    -1  
$EndComp
$Comp
L C ce1
U 1 1 575BE037
P 5800 3250
F 0 "ce1" H 5825 3350 50  0000 L CNN
F 1 "100u" H 5825 3150 50  0000 L CNN
F 2 "" H 5838 3100 50  0000 C CNN
F 3 "" H 5800 3250 50  0000 C CNN
	1    5800 3250
	1    0    0    -1  
$EndComp
$Comp
L R rs1
U 1 1 575BE2D9
P 4350 2900
F 0 "rs1" V 4430 2900 50  0000 C CNN
F 1 "50" V 4350 2900 50  0000 C CNN
F 2 "" V 4280 2900 50  0000 C CNN
F 3 "" H 4350 2900 50  0000 C CNN
	1    4350 2900
	0    1    1    0   
$EndComp
$Comp
L GND #PWR01
U 1 1 575BEF49
P 5550 3550
F 0 "#PWR01" H 5550 3300 50  0001 C CNN
F 1 "GND" H 5550 3400 50  0000 C CNN
F 2 "" H 5550 3550 50  0000 C CNN
F 3 "" H 5550 3550 50  0000 C CNN
	1    5550 3550
	1    0    0    -1  
$EndComp
Text GLabel 4000 2900 0    60   Input ~ 0
input
Text GLabel 6150 2250 1    60   Input ~ 0
output
Wire Wire Line
	5050 2500 6950 2500
Wire Wire Line
	5050 2800 5050 3150
Wire Wire Line
	5550 3400 5550 3550
Wire Wire Line
	5050 3450 6950 3450
Wire Wire Line
	4950 2900 5300 2900
Wire Wire Line
	5850 2700 5850 2750
Connection ~ 5300 3450
Wire Wire Line
	6950 3450 6950 3400
Connection ~ 5550 3450
Wire Wire Line
	5550 3100 5800 3100
Wire Wire Line
	5800 3450 5800 3400
Connection ~ 5800 3450
Wire Wire Line
	4500 2900 4650 2900
Connection ~ 5100 3450
Wire Wire Line
	6150 3050 6150 3450
Wire Wire Line
	6150 3450 6200 3450
Connection ~ 6200 3450
Wire Wire Line
	5100 3450 5100 3800
Wire Wire Line
	5100 3800 4200 3800
Wire Wire Line
	6150 2750 6150 2250
$Comp
L plot_v1 U1
U 1 1 575BFC27
P 4200 2700
F 0 "U1" H 4200 3200 60  0000 C CNN
F 1 "plot_v1" H 4400 3050 60  0000 C CNN
F 2 "" H 4200 2700 60  0000 C CNN
F 3 "" H 4200 2700 60  0000 C CNN
	1    4200 2700
	1    0    0    -1  
$EndComp
$Comp
L plot_v1 U2
U 1 1 575BFFD9
P 6150 2750
F 0 "U2" H 6150 3250 60  0000 C CNN
F 1 "plot_v1" H 6350 3100 60  0000 C CNN
F 2 "" H 6150 2750 60  0000 C CNN
F 3 "" H 6150 2750 60  0000 C CNN
	1    6150 2750
	0    1    1    0   
$EndComp
Wire Wire Line
	6150 2750 6350 2750
Wire Wire Line
	4200 2900 4200 2500
Connection ~ 4200 2900
Wire Wire Line
	5300 2800 5600 2800
Wire Wire Line
	5600 2800 5600 2700
Wire Wire Line
	5600 2700 5850 2700
Connection ~ 5050 2900
Connection ~ 5050 2500
Connection ~ 5600 3100
Connection ~ 5300 2500
Connection ~ 6150 2750
Wire Wire Line
	4200 2900 4000 2900
$Comp
L sine v2
U 1 1 575BEE36
P 4200 3350
F 0 "v2" H 4000 3450 60  0000 C CNN
F 1 "sine" H 4000 3300 60  0000 C CNN
F 2 "R1" H 3900 3350 60  0000 C CNN
F 3 "" H 4200 3350 60  0000 C CNN
	1    4200 3350
	1    0    0    -1  
$EndComp
$EndSCHEMATC
