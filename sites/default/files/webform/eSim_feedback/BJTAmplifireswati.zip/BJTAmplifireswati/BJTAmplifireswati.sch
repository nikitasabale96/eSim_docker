EESchema Schematic File Version 2
LIBS:power
LIBS:device
LIBS:transistors
LIBS:conn
LIBS:linear
LIBS:regul
LIBS:74xx
LIBS:cmos4000
LIBS:adc-dac
LIBS:memory
LIBS:xilinx
LIBS:microcontrollers
LIBS:dsp
LIBS:microchip
LIBS:analog_switches
LIBS:motorola
LIBS:texas
LIBS:intel
LIBS:audio
LIBS:interface
LIBS:digital-audio
LIBS:philips
LIBS:display
LIBS:cypress
LIBS:siliconi
LIBS:opto
LIBS:atmel
LIBS:contrib
LIBS:valves
LIBS:eSim_Analog
LIBS:eSim_Devices
LIBS:eSim_Digital
LIBS:eSim_Hybrid
LIBS:eSim_Miscellaneous
LIBS:eSim_Plot
LIBS:eSim_Power
LIBS:eSim_Sources
LIBS:eSim_Subckt
LIBS:eSim_User
LIBS:BJTAmplifireswati-cache
EELAYER 25 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 1
Title ""
Date ""
Rev ""
Comp ""
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L R R1
U 1 1 575BD344
P 2400 1950
F 0 "R1" V 2480 1950 50  0000 C CNN
F 1 "1k" V 2400 1950 50  0000 C CNN
F 2 "" V 2330 1950 50  0000 C CNN
F 3 "" H 2400 1950 50  0000 C CNN
	1    2400 1950
	1    0    0    -1  
$EndComp
$Comp
L R R2
U 1 1 575BD3C1
P 2650 4350
F 0 "R2" V 2730 4350 50  0000 C CNN
F 1 "1k" V 2650 4350 50  0000 C CNN
F 2 "" V 2580 4350 50  0000 C CNN
F 3 "" H 2650 4350 50  0000 C CNN
	1    2650 4350
	1    0    0    -1  
$EndComp
$Comp
L R R3
U 1 1 575BD437
P 4300 4600
F 0 "R3" V 4380 4600 50  0000 C CNN
F 1 "1k" V 4300 4600 50  0000 C CNN
F 2 "" V 4230 4600 50  0000 C CNN
F 3 "" H 4300 4600 50  0000 C CNN
	1    4300 4600
	1    0    0    -1  
$EndComp
$Comp
L R R4
U 1 1 575BD4C0
P 4400 2150
F 0 "R4" V 4480 2150 50  0000 C CNN
F 1 "1k" V 4400 2150 50  0000 C CNN
F 2 "" V 4330 2150 50  0000 C CNN
F 3 "" H 4400 2150 50  0000 C CNN
	1    4400 2150
	1    0    0    -1  
$EndComp
Wire Wire Line
	4300 3000 4300 2350
Wire Wire Line
	4300 2350 4400 2350
Wire Wire Line
	4400 2350 4400 2300
Wire Wire Line
	1350 2900 3950 2900
Wire Wire Line
	3950 2900 3950 3200
Wire Wire Line
	2400 2100 2400 4200
Connection ~ 2400 2900
Wire Wire Line
	2400 4200 2650 4200
Wire Wire Line
	2400 1800 6600 1800
Wire Wire Line
	4400 1800 4400 2000
Wire Wire Line
	4300 3400 4300 4450
Wire Wire Line
	2650 4500 2650 4850
Wire Wire Line
	6600 4850 1350 4850
Wire Wire Line
	4300 4850 4300 4750
Wire Wire Line
	4300 3500 5600 3500
Wire Wire Line
	5600 3500 5600 3550
Connection ~ 4300 3500
Wire Wire Line
	5600 4350 4300 4350
Wire Wire Line
	5600 3850 5600 4350
Connection ~ 4300 4350
$Comp
L GND #PWR01
U 1 1 575BE9E5
P 3400 4950
F 0 "#PWR01" H 3400 4700 50  0001 C CNN
F 1 "GND" H 3400 4800 50  0000 C CNN
F 2 "" H 3400 4950 50  0000 C CNN
F 3 "" H 3400 4950 50  0000 C CNN
	1    3400 4950
	1    0    0    -1  
$EndComp
Wire Wire Line
	3400 4950 3400 4850
Connection ~ 3400 4850
Connection ~ 2650 4850
$Comp
L DC v2
U 1 1 575BF462
P 6600 3150
F 0 "v2" H 6400 3250 60  0000 C CNN
F 1 "DC" H 6400 3100 60  0000 C CNN
F 2 "R1" H 6300 3150 60  0000 C CNN
F 3 "" H 6600 3150 60  0000 C CNN
	1    6600 3150
	1    0    0    -1  
$EndComp
Wire Wire Line
	6600 3600 6600 4850
Connection ~ 4300 4850
Wire Wire Line
	6600 1800 6600 2700
Connection ~ 4400 1800
Wire Wire Line
	4400 1800 4350 1800
Connection ~ 4350 1800
Text GLabel 1050 2600 0    60   Input ~ 0
IN
Wire Wire Line
	1050 2600 1450 2600
Connection ~ 1450 2900
$Comp
L plot_v1 U1
U 1 1 575C08F7
P 1450 2250
F 0 "U1" H 1450 2750 60  0000 C CNN
F 1 "plot_v1" H 1650 2600 60  0000 C CNN
F 2 "" H 1450 2250 60  0000 C CNN
F 3 "" H 1450 2250 60  0000 C CNN
	1    1450 2250
	1    0    0    -1  
$EndComp
Wire Wire Line
	1450 2900 1850 2900
Connection ~ 1850 2900
Wire Wire Line
	1450 2600 1450 2900
Wire Wire Line
	1450 2050 2100 2050
Wire Wire Line
	2100 2050 2100 2900
Connection ~ 2100 2900
$Comp
L plot_v1 U2
U 1 1 575C114F
P 7500 2600
F 0 "U2" H 7500 3100 60  0000 C CNN
F 1 "plot_v1" H 7700 2950 60  0000 C CNN
F 2 "" H 7500 2600 60  0000 C CNN
F 3 "" H 7500 2600 60  0000 C CNN
	1    7500 2600
	1    0    0    -1  
$EndComp
Wire Wire Line
	7500 2400 6600 2400
Wire Wire Line
	6600 2350 6600 2450
Connection ~ 6600 2450
Connection ~ 6600 2400
Connection ~ 6600 2350
$Comp
L sine v1
U 1 1 575BDE00
P 1350 3500
F 0 "v1" H 1150 3600 60  0000 C CNN
F 1 "sine" H 1150 3450 60  0000 C CNN
F 2 "R1" H 1050 3500 60  0000 C CNN
F 3 "" H 1350 3500 60  0000 C CNN
	1    1350 3500
	1    0    0    -1  
$EndComp
Wire Wire Line
	1350 3050 1350 2900
Wire Wire Line
	3950 3200 4000 3200
Wire Wire Line
	1350 4850 1350 3950
$Comp
L C C1
U 1 1 575C05E0
P 5600 3700
F 0 "C1" H 5625 3800 50  0000 L CNN
F 1 "1u" H 5625 3600 50  0000 L CNN
F 2 "" H 5638 3550 50  0000 C CNN
F 3 "" H 5600 3700 50  0000 C CNN
	1    5600 3700
	1    0    0    -1  
$EndComp
$Comp
L NPN Q1
U 1 1 575C0A12
P 4200 3200
F 0 "Q1" H 4100 3250 50  0000 R CNN
F 1 "NPN" H 4150 3350 50  0000 R CNN
F 2 "" H 4400 3300 29  0000 C CNN
F 3 "" H 4200 3200 60  0000 C CNN
	1    4200 3200
	1    0    0    -1  
$EndComp
$EndSCHEMATC
